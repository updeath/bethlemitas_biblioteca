<style>
    .colored-toast.swal2-icon-success {
        background-color: #a5dc86 !important;
    }

    .colored-toast.swal2-icon-error {
        background-color: #f27474 !important;
    }

    .colored-toast.swal2-icon-warning {
        background-color: #f8bb86 !important;
    }

    .colored-toast.swal2-icon-info {
        background-color: #3fc3ee !important;
    }

    .colored-toast.swal2-icon-question {
        background-color: #87adbd !important;
    }

    .colored-toast .swal2-title {
        color: white;
    }

    .colored-toast .swal2-close {
        color: white;
    }

    .colored-toast .swal2-html-container {
        color: white;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-md rounded-lg px-8 my-8 flex sm:w-[120vh] items-center">
    <!-- Formulario en dos columnas -->
    <form class="grid grid-cols-1 md:grid-cols-2 gap-4" action="<?php echo e(route('donations.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- Columna 1 -->
        <div>
            <h1 class="text-2xl font-bold "><em>Crear una Donación</em></h1>

            <!-- Codigo -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="code">Código</label>
                <input id="code" name="code" value="<?php echo e(old('code')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Código">
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Titulo del libro -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="title">Título del libro</label>
                <input id="title" name="title" value="<?php echo e(old('title')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Título">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Autor del libro -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="author">Autor del libro</label>
                <input id="author" name="author" value="<?php echo e(old('author')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Autor">
                <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Editorial -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="editorial">Editorial</label>
                <input type="text" id="editorial" name="editorial" value="<?php echo e(old('editorial')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Editorial">
                <?php $__errorArgs = ['editorial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Cantidad de libros -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="amount">Cantidad de libros</label>
                <input type="number" id="amount" name="amount" value="<?php echo e(old('amount')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Cantidad">
                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class=" text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Columna 2 -->
        <div class="sm:pl-10  pt-7">
            <div class="mb-3 col-span-6 sm:col-span-3">
                <label class="block text-sm font-bold text-gray-700 mb-2">Categoría:</label>
                <select id="category" name="category" value="<?php echo e(old('category')); ?>" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione una categoría</option>
                    <option value="libro" <?php echo e(old('category') == 'libro' ? 'selected' : ''); ?>>Libro</option>
                    <option value="tornos" <?php echo e(old('category') == 'tornos' ? 'selected' : ''); ?>>Tornos</option>
                    <option value="cartilla" <?php echo e(old('category') == 'cartilla' ? 'selected' : ''); ?>>Cartilla</option>
                    <option value="afiche" <?php echo e(old('category') == 'afiche' ? 'selected' : ''); ?>>Afiche</option>
                    <option value="folleto" <?php echo e(old('category') == 'folleto' ? 'selected' : ''); ?>>Folleto</option>
                    <option value="texto" <?php echo e(old('category') == 'texto' ? 'selected' : ''); ?>>Texto</option>
                </select>

                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Area -->
            <div class="mb-3 col-span-6 sm:col-span-3">
                <label for="area" class="block text-sm font-bold text-gray-700 mb-2">Área:</label>
                <select id="area" name="area" value="<?php echo e(old('area')); ?>" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione un área</option>
                    <option value="arte" <?php echo e(old('area') == 'arte' ? 'selected' : ''); ?>>Arte</option>
                    <option value="Atlasuniversal" <?php echo e(old('area') == 'Atlasuniversal' ? 'selected' : ''); ?>>Atlas universal</option>
                    <option value="Aprendizaje" <?php echo e(old('area') == 'Aprendizaje' ? 'selected' : ''); ?>>Aprendizaje</option>
                    <option value="Biblias" <?php echo e(old('area') == 'Biblias' ? 'selected' : ''); ?>>Biblias</option>
                    <option value="ciencia" <?php echo e(old('area') == 'ciencia' ? 'selected' : ''); ?>>Ciencia</option>
                    <option value="sociales" <?php echo e(old('area') == 'sociales' ? 'selected' : ''); ?>>Ciencias sociales</option>
                    <option value="Cienciaspolíticaseconómicas" <?php echo e(old('area') == 'Cienciaspolíticaseconómicas' ? 'selected' : ''); ?>>Ciencias políticas y económicas</option>
                    <option value="Ciencianaturales" <?php echo e(old('area') == 'Ciencianaturales' ? 'selected' : ''); ?>>Ciencias Naturales</option>
                    <option value="CienciaComputer" <?php echo e(old('area') == 'CienciaComputer' ? 'selected' : ''); ?>>Ciencia de la Computación</option>
                    <option value="Cienciasalud" <?php echo e(old('area') == 'Cienciasalud' ? 'selected' : ''); ?>>Ciencias de la Salud</option>
                    <option value="Cienciasnaturalesbiología" <?php echo e(old('area') == 'Cienciasnaturalesbiología' ? 'selected' : ''); ?>>Ciencias naturales y biología</option>
                    <option value="Comportamientosalud" <?php echo e(old('area') == 'Comportamientosalud' ? 'selected' : ''); ?>>Comportamiento y salud</option>
                    <option value="Diccionariosinglés" <?php echo e(old('area') == 'Diccionariosinglés' ? 'selected' : ''); ?>>Diccionarios inglés</option>
                    <option value="Diccionariosespañol" <?php echo e(old('area') == 'Diccionariosespañol' ? 'selected' : ''); ?>>Diccionarios español</option>
                    <option value="Educacionsalud" <?php echo e(old('area') == 'Educacionsalud' ? 'selected' : ''); ?>>Educación en Salud</option>
                    <option value="EconomiaPolitica" <?php echo e(old('area') == 'EconomiaPolitica' ? 'selected' : ''); ?>>Economía Política</option>
                    <option value="ÉticaValores" <?php echo e(old('area') == 'ÉticaValores' ? 'selected' : ''); ?>>Ética y Valores</option>
                    <option value="Educación" <?php echo e(old('area') == 'Educación' ? 'selected' : ''); ?>>Educación</option>
                    <option value="Ecología" <?php echo e(old('area') == 'Ecología' ? 'selected' : ''); ?>>Ecología</option>
                    <option value="Energía" <?php echo e(old('area') == 'Energía' ? 'selected' : ''); ?>>Energía</option>
                    <option value="Fichasingles" <?php echo e(old('area') == 'Fichasingles' ? 'selected' : ''); ?>>Fichas de ingles</option>
                    <option value="Físicamatemática" <?php echo e(old('area') == 'Físicamatemática' ? 'selected' : ''); ?>>Física matemática</option>
                    <option value="historia" <?php echo e(old('area') == 'historia' ? 'selected' : ''); ?>>Historia</option>
                    <option value="Ingles" <?php echo e(old('area') == 'Ingles' ? 'selected' : ''); ?>>Ingles</option>
                    <option value="informacion" <?php echo e(old('area') == 'informacion' ? 'selected' : ''); ?>>Información</option>
                    <option value="Informaciongeneral" <?php echo e(old('area') == 'Informaciongeneral' ? 'selected' : ''); ?>>Información General</option>
                    <option value="literatura" <?php echo e(old('area') == 'literatura' ? 'selected' : ''); ?>>Literatura</option>
                    <option value="lenguas" <?php echo e(old('area') == 'lenguas' ? 'selected' : ''); ?>>Lenguas</option>
                    <option value="Liderazgo" <?php echo e(old('area') == 'Liderazgo' ? 'selected' : ''); ?>>Liderazgo</option>
                    <option value="Literaturamoderna" <?php echo e(old('area') == 'Literaturamoderna' ? 'selected' : ''); ?>>Literatura moderna</option>
                    <option value="Literaturaantigua" <?php echo e(old('area') == 'Literaturaantigua' ? 'selected' : ''); ?>>Literatura antigua</option>
                    <option value="Literaturainfantil" <?php echo e(old('area') == 'Literaturainfantil' ? 'selected' : ''); ?>>Literatura infantil</option> 
                    <option value="Matemáticas" <?php echo e(old('area') == 'Matemáticas' ? 'selected' : ''); ?>>Matemáticas</option>
                    <option value="medioambiente" <?php echo e(old('area') == 'medioambiente' ? 'selected' : ''); ?>>Medio ambiente</option>
                    <option value="psicologia" <?php echo e(old('area') == 'psicologia' ? 'selected' : ''); ?>>Psicología</option>
                    <option value="politica" <?php echo e(old('area') == 'politica' ? 'selected' : ''); ?>>Política</option>
                    <option value="Química" <?php echo e(old('area') == 'Química' ? 'selected' : ''); ?>>Química</option>
                    <option value="religion" <?php echo e(old('area') == 'religion' ? 'selected' : ''); ?>>Religión</option>     
                    
                </select>
                <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Estado del libro -->
            <div class="mb-3 col-span-6 sm:col-span-3">
                <label for="status" class="block text-sm font-bold text-gray-700 mb-2">Estado del libro:</label>
                <select id="status" name="status" value="<?php echo e(old('status')); ?>" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione su Estado</option>
                    <option value="well" <?php echo e(old('status') == 'well' ? 'selected' : ''); ?>>Bueno</option>
                    <option value="regular" <?php echo e(old('status') == 'regular' ? 'selected' : ''); ?>>Regular</option>
                    <option value="bad" <?php echo e(old('status') == 'bad' ? 'selected' : ''); ?>>Malo</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Clasificacion del libro -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="classification mb-2">Clasificación del libro</label>
                <input type="text" id="classification" name="classification" value="<?php echo e(old('classification')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Clasificación">
                <?php $__errorArgs = ['classification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Año de la donación del libro -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="year">Año de la donación del libro</label>
                <input type="number" id="year" name="year" value="<?php echo e(old('year')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Año de donación" min="2010" max="<?php echo e(date('Y')); ?>">
                <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Ingrese un año válido</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Imagen del libro -->
            <div class="">
                <label class="block text-gray-700 text-sm font-bold" for="image">Imagen del libro</label>
                <input type="file" id="image" name="image" accept="image/*">
            </div>

        </div>

        <!-- Botón de envío -->
        <div class="flex justify-center ">
                <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                    Añadir a la tabla de Donaciones
                </button>
            </div>
    </form>
</div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('success')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                iconColor: 'white',
                customClass: {
                    popup: 'colored-toast',
                },
                showConfirmButton: false,
                timer: 2500,
                timerProgressBar: true,
            });
            Toast.fire({
                icon: 'success',
                title: '<?php echo e(session('success')); ?>',
            });
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Bethlemitas-Biblioteca\resources\views/home/donations/create.blade.php ENDPATH**/ ?>