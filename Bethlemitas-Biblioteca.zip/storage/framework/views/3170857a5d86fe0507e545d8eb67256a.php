<style>
    .colored-toast.swal2-icon-success {
        background-color: #a5dc86 !important;
    }

    .colored-toast.swal2-icon-error {
        background-color: #f27474 !important;
    }

    .colored-toast.swal2-icon-warning {
        background-color: #f8bb86 !important;
    }

    .colored-toast.swal2-icon-info {
        background-color: #3fc3ee !important;
    }

    .colored-toast.swal2-icon-question {
        background-color: #87adbd !important;
    }

    .colored-toast .swal2-title {
        color: white;
    }

    .colored-toast .swal2-close {
        color: white;
    }

    .colored-toast .swal2-html-container {
        color: white;
    }
</style>

<?php $__env->startSection('content'); ?>
    <div class="bg-white shadow-md rounded-lg my-[60px] p-5 flex w-3/4 items-center">
        <!-- Formulario en la parte izquierda -->
        <form class="w-full md:flex" action="<?php echo e(route('user.profileUpdate')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="w-full md:w-1/2 md:pr-4">
                <h1 class="text-2xl font-bold mb-4"><em>Ingresa los datos a modificar:</em></h1>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="nombre">
                        <em>Nombre</em>
                    </label>
                        <input id="name" name="name" value="<?php echo e(auth()->user() ? auth()->user()->name : ''); ?>"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        type="text" placeholder="Nombre">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="apellido">
                        <em>Apellido</em>
                    </label>
                    <input id="last_name" name="last_name" value="<?php echo e(auth()->user() ? auth()->user()->last_name : ''); ?>"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        type="text" placeholder="Apellido">
                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="email">
                        <em>Correo electrónico</em>
                    </label>
                    <input id="email" name="email" value="<?php echo e(auth()->user() ? auth()->user()->email : ''); ?>"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        type="email" placeholder="Correo Electrónico">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="email">
                        <em>Cambiar contraseña</em>
                    </label>

                    <input type="password" id="password" name="password"  value="<?php echo e(auth()->user() ? auth()->user()->password : ''); ?>"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        placeholder="***********">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="foto">
                        <em>Foto</em>
                    </label>
                    <input type="file" id="image" name="image" accept="image/*">
                </div>
                <div class="flex items-center justify-between">
                    <button
                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        type="submit">
                        <em>Editar</em>
                    </button>
                </div>
            </div>


            <!-- Tarjeta en la parte derecha -->
            <div class="w-full md:w-1/2 p-3">
                <div class="text-center">
                    <?php if(auth()->user() ? auth()->user()->image : ''): ?>
                        <img name='image' id="image" src="<?php echo e(asset(auth()->user() ? auth()->user()->image : '')); ?>" alt="Foto del perfil"
                            class="rounded-full mx-auto mb-4">
                    <?php else: ?>
                        <img src="https://placekitten.com/200/200" alt="Foto de ejemplo" class="rounded-full mx-auto mb-4">
                    <?php endif; ?>
                </div>
                <div class="bg-gray-200 p-4 rounded">
                    <h2 class="text-xl font-bold mb-4"><em>Información Adicional</em></h2>
                    <em><p><b>Nombre Completo:  </b><?php echo e(auth()->user() ? auth()->user()->name : ''); ?> <?php echo e(auth()->user() ? auth()->user()->last_name : ''); ?></p></em>
                    
                    <em><p><b>email:  </b><?php echo e(auth()->user() ? auth()->user()->email : ''); ?></p></em>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('success')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                iconColor: 'white',
                customClass: {
                    popup: 'colored-toast',
                },
                showConfirmButton: false,
                timer: 2500,
                timerProgressBar: true,
            });
            Toast.fire({
                icon: 'success',
                title: '<?php echo e(session('success')); ?>',
            });
        </script>
    <?php endif; ?>

    <?php if(session('info')): ?>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            iconColor: 'white',
            customClass: {
                popup: 'colored-toast',
            },
            showConfirmButton: false,
            timer: 2500,
            timerProgressBar: true,
        });
        Toast.fire({
            icon: 'info',
            title: '<?php echo e(session('info')); ?>',
        });
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Bethlemitas-Biblioteca\resources\views/home/profile.blade.php ENDPATH**/ ?>