<style>
    .colored-toast.swal2-icon-success {
        background-color: #a5dc86 !important;
    }

    .colored-toast.swal2-icon-error {
        background-color: #f27474 !important;
    }

    .colored-toast.swal2-icon-warning {
        background-color: #f8bb86 !important;
    }

    .colored-toast.swal2-icon-info {
        background-color: #3fc3ee !important;
    }

    .colored-toast.swal2-icon-question {
        background-color: #87adbd !important;
    }

    .colored-toast .swal2-title {
        color: white;
    }

    .colored-toast .swal2-close {
        color: white;
    }

    .colored-toast .swal2-html-container {
        color: white;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-md rounded-lg px-8 my-8 flex items-center" style="width: 47rem; padding: 2rem">
    <!-- Formulario en dos columnas -->
    <form class="grid grid-cols-1 md:grid-cols-2 gap-4" action="<?php echo e(route('inventory.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- Columna 1 -->
        <div>
            <h1 class="text-2xl font-bold "><em>Crear Registro</em></h1>

            <!-- Codigo -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="code">Código</label>
                <input id="code" name="code" value="<?php echo e(old('code')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Código">
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="clasifpgc">CLASIF PGC</label>
                <input placeholder="CLASIF PGC" min="99" id="clasifpgc" name="clasifpgc" value="<?php echo e(old('clasifpgc')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="number">
                <?php $__errorArgs = ['clasifpgc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Titulo del libro -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="title">Título del libro</label>
                <input id="title" name="title" value="<?php echo e(old('title')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Título">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <!-- Editorial -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="editorial">Editorial</label>
                <input type="text" id="editorial" name="editorial" value="<?php echo e(old('editorial')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Editorial">
                <?php $__errorArgs = ['editorial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Cantidad de libros -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="amount">Cantidad</label>
                <input type="number" id="amount" name="amount" value="<?php echo e(old('amount')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Cantidad">
                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class=" text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-span-6 sm:col-span-3">
                <label class="block text-sm font-bold text-gray-700 mb-2">Categoría:</label>
                <select id="category" name="category" value="<?php echo e(old('category')); ?>" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione una categoría</option>
                    <option value="libro" <?php echo e(old('category') == 'libro' ? 'selected' : ''); ?>>Libro</option>
                    <option value="tornos" <?php echo e(old('category') == 'tornos' ? 'selected' : ''); ?>>Tornos</option>
                    <option value="cartilla" <?php echo e(old('category') == 'cartilla' ? 'selected' : ''); ?>>Cartilla</option>
                    <option value="afiche" <?php echo e(old('category') == 'afiche' ? 'selected' : ''); ?>>Afiche</option>
                    <option value="folleto" <?php echo e(old('category') == 'folleto' ? 'selected' : ''); ?>>Folleto</option>
                    <option value="texto" <?php echo e(old('category') == 'texto' ? 'selected' : ''); ?>>Texto</option>
                </select>
                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
        <div class="sm:pl-10 pt-7" >

            <!-- Autor del libro -->
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="author">Autor del libro</label>
                <input id="author" name="author" value="<?php echo e(old('author')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Autor">
                <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Area -->
            <div class="mb-3 col-span-6 sm:col-span-3">
                <label for="area" class="block text-sm font-bold text-gray-700 mb-2">Área:</label>
                <select id="area" name="area" value="<?php echo e(old('area')); ?>" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione un área</option>
                    <option value="Arte" <?php echo e(old('area') == 'arte' ? 'selected' : ''); ?>>Arte</option>
                    <option value="Atlas universal" <?php echo e(old('area') == 'Atlasuniversal' ? 'selected' : ''); ?>>Atlas universal</option>
                    <option value="Aprendizaje" <?php echo e(old('area') == 'Aprendizaje' ? 'selected' : ''); ?>>Aprendizaje</option>
                    <option value="Biblias" <?php echo e(old('area') == 'Biblias' ? 'selected' : ''); ?>>Biblias</option>
                    <option value="Ciencia" <?php echo e(old('area') == 'ciencia' ? 'selected' : ''); ?>>Ciencia</option>
                    <option value="Ciencias sociales" <?php echo e(old('area') == 'sociales' ? 'selected' : ''); ?>>Ciencias sociales</option>
                    <option value="Ciencias políticas y económicas" <?php echo e(old('area') == 'Cienciaspolíticaseconómicas' ? 'selected' : ''); ?>>Ciencias políticas y económicas</option>
                    <option value="Ciencia naturales" <?php echo e(old('area') == 'Ciencianaturales' ? 'selected' : ''); ?>>Ciencias Naturales</option>
                    <option value="Ciencia de la Computación" <?php echo e(old('area') == 'CienciaComputer' ? 'selected' : ''); ?>>Ciencia de la Computación</option>
                    <option value="Ciencias de la Salud" <?php echo e(old('area') == 'Cienciasalud' ? 'selected' : ''); ?>>Ciencias de la Salud</option>
                    <option value="Ciencias naturales y biología" <?php echo e(old('area') == 'Cienciasnaturalesbiología' ? 'selected' : ''); ?>>Ciencias naturales y biología</option>
                    <option value="Comportamiento y salud" <?php echo e(old('area') == 'Comportamientosalud' ? 'selected' : ''); ?>>Comportamiento y salud</option>
                    <option value="Diccionarios inglés" <?php echo e(old('area') == 'Diccionariosinglés' ? 'selected' : ''); ?>>Diccionarios inglés</option>
                    <option value="Diccionarios español" <?php echo e(old('area') == 'Diccionariosespañol' ? 'selected' : ''); ?>>Diccionarios español</option>
                    <option value="Educación en Salud" <?php echo e(old('area') == 'Educacionsalud' ? 'selected' : ''); ?>>Educación en Salud</option>
                    <option value="Economía Política" <?php echo e(old('area') == 'EconomiaPolitica' ? 'selected' : ''); ?>>Economía Política</option>
                    <option value="Ética y Valores" <?php echo e(old('area') == 'ÉticaValores' ? 'selected' : ''); ?>>Ética y Valores</option>
                    <option value="Educación" <?php echo e(old('area') == 'Educación' ? 'selected' : ''); ?>>Educación</option>
                    <option value="Ecología" <?php echo e(old('area') == 'Ecología' ? 'selected' : ''); ?>>Ecología</option>
                    <option value="Energía" <?php echo e(old('area') == 'Energía' ? 'selected' : ''); ?>>Energía</option>
                    <option value="Fichas de ingles" <?php echo e(old('area') == 'Fichasingles' ? 'selected' : ''); ?>>Fichas de ingles</option>
                    <option value="Física matemática" <?php echo e(old('area') == 'Físicamatemática' ? 'selected' : ''); ?>>Física matemática</option>
                    <option value="Historia" <?php echo e(old('area') == 'historia' ? 'selected' : ''); ?>>Historia</option>
                    <option value="Inglés" <?php echo e(old('area') == 'Ingles' ? 'selected' : ''); ?>>Ingles</option>
                    <option value="Información" <?php echo e(old('area') == 'informacion' ? 'selected' : ''); ?>>Información</option>
                    <option value="Información general" <?php echo e(old('area') == 'Informaciongeneral' ? 'selected' : ''); ?>>Información General</option>
                    <option value="literatura" <?php echo e(old('area') == 'literatura' ? 'selected' : ''); ?>>Literatura</option>
                    <option value="lenguas" <?php echo e(old('area') == 'lenguas' ? 'selected' : ''); ?>>Lenguas</option>
                    <option value="Liderazgo" <?php echo e(old('area') == 'Liderazgo' ? 'selected' : ''); ?>>Liderazgo</option>
                    <option value="Literatura moderna" <?php echo e(old('area') == 'Literaturamoderna' ? 'selected' : ''); ?>>Literatura moderna</option>
                    <option value="Literatura antigua" <?php echo e(old('area') == 'Literaturaantigua' ? 'selected' : ''); ?>>Literatura antigua</option>
                    <option value="Literatura infantil" <?php echo e(old('area') == 'Literaturainfantil' ? 'selected' : ''); ?>>Literatura infantil</option>
                    <option value="Matemáticas" <?php echo e(old('area') == 'Matemáticas' ? 'selected' : ''); ?>>Matemáticas</option>
                    <option value="Medio ambiente" <?php echo e(old('area') == 'medioambiente' ? 'selected' : ''); ?>>Medio ambiente</option>
                    <option value="Psicología" <?php echo e(old('area') == 'psicologia' ? 'selected' : ''); ?>>Psicología</option>
                    <option value="Política" <?php echo e(old('area') == 'politica' ? 'selected' : ''); ?>>Política</option>
                    <option value="Química" <?php echo e(old('area') == 'Química' ? 'selected' : ''); ?>>Química</option>
                    <option value="Religion" <?php echo e(old('area') == 'religion' ? 'selected' : ''); ?>>Religión</option>

                </select>
                <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <!-- Estado del libro -->
            <div class="mb-3 col-span-6 sm:col-span-3">
                <label for="status" class="block text-sm font-bold text-gray-700 mb-2">Estado del libro:</label>
                <select id="status" name="status" value="<?php echo e(old('status')); ?>" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione su Estado</option>
                    <option value="well" <?php echo e(old('status') == 'well' ? 'selected' : ''); ?>>Bueno</option>
                    <option value="regular" <?php echo e(old('status') == 'regular' ? 'selected' : ''); ?>>Regular</option>
                    <option value="bad" <?php echo e(old('status') == 'bad' ? 'selected' : ''); ?>>Malo</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="mb-3 col-span-6 sm:col-span-3">
                <label for="activite" class="block text-sm font-bold text-gray-700 mb-2">Actividad:</label>
                <select id="activite" name="activite" value="<?php echo e(old('activite')); ?>" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione su Actividad</option>
                    <option value="reference_material" <?php echo e(old('activite') == 'reference_material' ? 'selected' : ''); ?>>Material de referencia</option>
                    <option value="investigation" <?php echo e(old('activite') == 'investigation' ? 'selected' : ''); ?>>Investigación</option>
                    <option value="teaching" <?php echo e(old('activite') == 'teaching' ? 'selected' : ''); ?>>Enseñanza</option>
                    <option value="consultation" <?php echo e(old('activite') == 'consultation' ? 'selected' : ''); ?>>Consulta</option>
                    <option value="languagues" <?php echo e(old('activite') == 'languagues' ? 'selected' : ''); ?>>Idiomas</option>
                    <option value="reading" <?php echo e(old('activite') == 'reading' ? 'selected' : ''); ?>>Lectura</option>
                </select>
                <?php $__errorArgs = ['activite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="year">Año del Registro</label>
                <input type="number" id="year" name="year" value="<?php echo e(old('year')); ?>" class="w-full shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Año de donación" min="2010" max="<?php echo e(date('Y')); ?>">
                <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Ingrese un año válido</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-span-6 sm:col-span-3">
                <label for="action" class="block text-sm font-bold text-gray-700 mb-2">Acción:</label>
                <select id="action" name="action" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300">
                    <option selected disabled value="">Seleccione una acción</option>
                    <option value="donaciones" <?php echo e(old('action') == 'donaciones' ? 'selected' : ''); ?>>Donaciones</option>
                    <option value="descartaciones" <?php echo e(old('action') == 'descartaciones' ? 'selected' : ''); ?>>Descartes</option>
                    <option value="inventario" <?php echo e(old('action') == 'inventario' ? 'selected' : ''); ?>>Inventario</option>
                </select>
                <?php $__errorArgs = ['action'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Seleccione una acción válida</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="">
                <label class="block text-gray-700 text-sm font-bold" for="image">Imagen del libro</label>
                <input type="file" id="image" name="image" accept="image/*">
            </div>
        </div>
        <!-- Botón de envío -->
        <div class="flex items-center w-full">
            <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                Añadir Registro
            </button>
        </div>

    </form>
</div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('success')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                iconColor: 'white',
                customClass: {
                    popup: 'colored-toast',
                },
                showConfirmButton: false,
                timer: 2500,
                timerProgressBar: true,
            });
            Toast.fire({
                icon: 'success',
                title: '<?php echo e(session('success')); ?>',
            });
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Bethlemitas-Biblioteca\resources\views/home/inventory/create.blade.php ENDPATH**/ ?>